# GraphQL-React-Native-Ordering-App

Hello everyone, in this project, i will develop a project that ordering product application over mobile devices on platforms Android, iOS. I will use GraphQL for querying MongoDB ( i am using mLab Sandbox 500mB.). Authentication of the application will be based on JWT. I hope this example will demonstrate basic and so useful features of GraphQL and will help people who wants to learn GraphQL. I am going to use React Native for mobile application development.

If you are testing the application with Postman, note that you have to send token to graphql as 'Bearer token'
